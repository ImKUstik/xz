# Snail Tamagotchi — Android project

Проект упаковывает исходную HTML-игру в Android WebView.
HTML и видео находятся в `app/src/main/assets/`. Видео скопировано под именем
`turbo.mp4`, которое ожидает исходный HTML.

## Онлайн-сборка APK через GitHub Actions (без установки Android Studio)
1. Войдите на github.com или создайте аккаунт.
2. Создайте новый репозиторий (например, `snail-tamagotchi`).
3. Распакуйте этот ZIP на устройстве/компьютере и загрузите ВСЁ содержимое папки проекта в репозиторий. Включая скрытую папку `.github/workflows`.
4. Откройте вкладку **Actions** репозитория. Если GitHub попросит разрешить workflows, нажмите разрешение.
5. Выберите **Build Android APK** → **Run workflow** → **Run workflow**.
6. Дождитесь зелёной галочки. Откройте завершившийся запуск и скачайте artifact **SnailTamagotchi-APK**.
7. Распакуйте скачанный artifact — внутри будет `app-debug.apk`. Это и есть установочный APK.

Сборка также запускается автоматически после загрузки изменений в ветку `main`.
Для APK используется debug-подпись; для Google Play понадобится отдельная release-сборка
с собственной подписью.

## Сборка локально
Откройте проект в Android Studio (JDK 17+, Android SDK Platform 35), затем
Build → Build Bundle(s) / APK(s) → Build APK(s).
